//
//  ViewController.swift
//  guessWhat_T12
//
//  Created by Chloe Kim on 2019-03-13.
//  Copyright © 2019 T12. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

